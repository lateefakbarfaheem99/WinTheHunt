<!-- there is no license data here, yet -->
<span style="font-size:11px">phpPennyAuction version: <?= PHPPA_VERSION ?> (build <?= PHPPA_BUILD ?>)</span>
<center>
<!--end license data. do not edit the above -->
