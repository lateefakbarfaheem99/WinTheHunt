<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <title>Nothing here</title>
  <meta http-equiv="Refresh" content="0; URL=../">
</head>
<body>
<div style="text-align: center; font-family: arial;"><big><big>Nothing here<br>
<br>
<a href="../">Go back this way!</a>
</big></big></div>
</body>
</html>