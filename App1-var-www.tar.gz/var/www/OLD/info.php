<?php
phpinfo();

// just a test :D
?>

