<?php
App::import('Vendor', 'phpmailer'.DS.'phpmailer');

class MailerComponent extends PHPMailer{

}
?>