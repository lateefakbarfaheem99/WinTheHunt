<?php 

echo phpinfo();
?>